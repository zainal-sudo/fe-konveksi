import { createRouter, createWebHistory } from "vue-router";
import { useAuthStore } from "@/stores/authStore";
import { usePermissionStore } from "@/stores/permissionStore";
import { useTabsStore } from "@/stores/tabsStore";
import { useDynamicRoutes } from "@/composables/useDynamicRoutes";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    // ── Auth ──────────────────────────────────────────────────────────
    {
      path: "/login",
      name: "Login",
      component: () => import("@/views/auth/LoginView.vue"),
      meta: { title: "Login", layout: "BlankLayout", requiresAuth: false },
    },

    // ── Dashboard ─────────────────────────────────────────────────────
    {
      path: "/",
      name: "Dashboard",
      component: () => import("@/views/dashboard/DashboardView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        requiresPermission: false,
        title: "Dashboard",
      },
    },

    // ── Master ────────────────────────────────────────────────────────
    {
      path: "/master/Supplier",
      name: "MasterSupplier",
      component: () => import("@/views/master/SupplierView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "10",
        title: "Master Supplier",
      },
    },
    {
      path: "/master/kategori",
      name: "MasterKategori",
      component: () => import("@/views/master/KategoriView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "11",
        title: "Master Kategori",
      },
    },
    {
      path: "/master/barang",
      name: "MasterBarang",
      component: () => import("@/views/master/BarangView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "13",
        title: "Master Barang",
      },
    },
    {
      path: "/master/customer",
      name: "MasterCustomer",
      component: () => import("@/views/master/CustomerView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "14",
        title: "Master Customer",
      },
    },
    {
      path: "/master/gudang",
      name: "MasterGudang",
      component: () => import("@/views/master/GudangView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "16",
        title: "Master Gudang",
      },

    },
    {
      path: "/master/kelompok",
      name: "MasterKelompok",
      component: () => import("@/views/master/KelompokView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "7",
        title: "Master Kelompok",
      },
    },
    {
      path: "/master/rekening",
      name: "MasterRekening",
      component: () => import("@/views/master/RekeningView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "6",
        title: "Master Rekening",
      },
    },


    // ── Transaksi ─────────────────────────────────────────────────────
    {
      path: "/transaksi/po",
      name: "poBrowse",
      component: () => import("@/views/transaksi/poBrowseView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "15",
        title: "PO",
      },
    },
    {
      path: "/transaksi/po/create",
      name: "poCreate",
      component: () => import("@/views/transaksi/poFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "15",
        title: "Tambah PO",
        browseRoute: "poBrowse",
      },
    },
    {
      path: "/transaksi/po/edit/:nomor",
      name: "poEdit",
      component: () => import("@/views/transaksi/poFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "15",
        title: "Ubah PO",
        browseRoute: "poBrowse",
      },
    },

    {
      path: "/transaksi/po/print/:nomor",
      name: "poPrint",
      component: () => import("@/views/transaksi/poPrintView.vue"),
      meta: {
        layout: "BlankLayout",
        requiresAuth: true,
        title: "Cetak PO",
      },
    },
    {
      path: "/transaksi/bpb",
      name: "bpbBrowse",
      component: () => import("@/views/transaksi/bpbBrowseView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "17",
        browseRoute: "bpbBrowse",
      },
    },
    {
      path: "/transaksi/bpb/baru",
      name: "bpbCreate",
      component: () => import("@/views/transaksi/bpbFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "17",
        title: "Tambah BPB",
        browseRoute: "bpbBrowse",
      },
    },
    {
      path: "/transaksi/bpb/ubah/:nomor",
      name: "bpbEdit",
      component: () => import("@/views/transaksi/bpbFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "17",
        title: "Ubah BPB",
        browseRoute: "bpbBrowse",
      },
    },
    {
      path: "/transaksi/retur",
      name: "returBrowse",
      component: () => import("@/views/transaksi/returBrowseView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "19",
        browseRoute: "returBrowse",
      },
    },
    {
      path: "/transaksi/retur/baru",
      name: "returCreate",
      component: () => import("@/views/transaksi/returFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "19",
        title: "Tambah Retur",
        browseRoute: "returBrowse",
      },
    },
    {
      path: "/transaksi/retur/ubah/:nomor",
      name: "returEdit",
      component: () => import("@/views/transaksi/returFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "19",
        title: "Ubah Retur",
        browseRoute: "returBrowse",
      },
    },
    {
      path: "/transaksi/bayarSupplier",
      name: "bayarSupplierBrowse",
      component: () => import("@/views/transaksi/bayarSupplierView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "53",
        browseRoute: "bayarSupplierBrowse",
      },
    },
    {
      path: "/transaksi/bayarSupplier/baru",
      name: "bayarSupplierCreate",
      component: () => import("@/views/transaksi/bayarSupplierForm.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "53",
        title: "Tambah bayarSupplier",
        browseRoute: "bayarSupplierBrowse",
      },
    },
    {
      path: "/transaksi/bayarSupplier/ubah/:nomor",
      name: "bayarSupplierEdit",
      component: () => import("@/views/transaksi/bayarSupplierForm.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "53",
        title: "Ubah bayarSupplier",
        browseRoute: "bayarSupplierBrowse",
      },
    },
    {
      path: "/transaksi/penjualan",
      name: "penjualanBrowse",
      component: () => import("@/views/transaksi/penjualanBrowseView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "33",
        title: "Ubah Penjualan",
        browseRoute: "penjualanBrowse",
      }

    },
    {
      path: "/transaksi/penjualan/form",
      name: "penjualanCreate",
      component: () => import("@/views/transaksi/penjualanFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "33",
        title: "Mesin Kasir",
        browseRoute: "penjualanBrowse",
      }

    },
    // MUTASI OUT
    {
      path: "/transaksi/mutasi-out",
      name: "MutasiOut",
      component: () => import("@/views/transaksi/MutasiOutView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "31",
        title: "Mutasi Out Garmen",
      },
    },
    {
      path: "/transaksi/mutasi-out/create",
      name: "MutasiOutCreate",
      component: () => import("@/views/transaksi/MutasiOutFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "31",
        title: "Buat Mutasi Out",
        browseRoute: "MutasiOut",
      },
    },
    {
      path: "/transaksi/mutasi-out/edit/:nomor",
      name: "MutasiOutEdit",
      component: () => import("@/views/transaksi/MutasiOutFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "31",
        title: "Ubah Mutasi Out",
        browseRoute: "MutasiOut",
      },
    },
    {
      path: "/transaksi/mutasi-out/print/:nomor",
      name: "MutasiOutPrint",
      component: () => import("@/views/transaksi/MutasiOutPrintView.vue"),
      meta: {
        layout: "BlankLayout",
        requiresAuth: true,
        title: "Cetak Mutasi Out",
      },
    },

    // BKM
    {
      path: "/transaksi/bkm",
      name: "BkmBrowse",
      component: () => import("@/views/transaksi/BkmView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "23",
        title: "Bukti Kas Masuk",
      },
    },
    {
      path: "/transaksi/bkm/create",
      name: "BkmCreate",
      component: () => import("@/views/transaksi/BkmFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "23",
        title: "Tambah BKM",
        browseRoute: "BkmBrowse",
      },
    },
    {
      path: "/transaksi/bkm/edit/:nomor",
      name: "BkmEdit",
      component: () => import("@/views/transaksi/BkmFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "23",
        title: "Ubah BKM",
        browseRoute: "BkmBrowse",
      },
    },
    {
      path: "/transaksi/bkm/print/:nomor",
      name: "BkmPrint",
      component: () => import("@/views/transaksi/BkmPrintView.vue"),
      meta: { layout: "BlankLayout", requiresAuth: true, title: "Cetak BKM" },
    },
    // BKK
    {
      path: "/transaksi/bkk",
      name: "BkkBrowse",
      component: () => import("@/views/transaksi/BkkView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "22",
        title: "Bukti Kas Keluar",
      },
    },
    {
      path: "/transaksi/bkk/create",
      name: "BkkCreate",
      component: () => import("@/views/transaksi/BkkFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "22",
        title: "Tambah BKK",
        browseRoute: "BkkBrowse",
      },
    },
    {
      path: "/transaksi/bkk/edit/:nomor",
      name: "BkkEdit",
      component: () => import("@/views/transaksi/BkkFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "22",
        title: "Ubah BKK",
        browseRoute: "BkkBrowse",
      },
    },
    {
      path: "/transaksi/bkk/print/:nomor",
      name: "BkkPrint",
      component: () => import("@/views/transaksi/BkkPrintView.vue"),
      meta: { layout: "BlankLayout", requiresAuth: true, title: "Cetak BKK" },
    },
    // BBM
    {
      path: "/transaksi/bbm",
      name: "BbmBrowse",
      component: () => import("@/views/transaksi/BbmView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "25",
        title: "Bukti Bank Masuk",
      },
    },
    {
      path: "/transaksi/bbm/create",
      name: "BbmCreate",
      component: () => import("@/views/transaksi/BbmFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "25",
        title: "Tambah BBM",
        browseRoute: "BbmBrowse",
      },
    },
    {
      path: "/transaksi/bbm/edit/:nomor",
      name: "BbmEdit",
      component: () => import("@/views/transaksi/BbmFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "25",
        title: "Ubah BBM",
        browseRoute: "BbmBrowse",
      },
    },
    {
      path: "/transaksi/bbm/print/:nomor",
      name: "BbmPrint",
      component: () => import("@/views/transaksi/BbmPrintView.vue"),
      meta: { layout: "BlankLayout", requiresAuth: true, title: "Cetak BBM" },
    },
    // BBK
    {
      path: "/transaksi/bbk",
      name: "BbkBrowse",
      component: () => import("@/views/transaksi/BbkView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "24",
        title: "Bukti Bank Keluar",
      },
    },
    {
      path: "/transaksi/bbk/create",
      name: "BbkCreate",
      component: () => import("@/views/transaksi/BbkFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "24",
        title: "Tambah BBK",
        browseRoute: "BbkBrowse",
      },
    },
    {
      path: "/transaksi/bbk/edit/:nomor",
      name: "BbkEdit",
      component: () => import("@/views/transaksi/BbkFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "24",
        title: "Ubah BBK",
        browseRoute: "BbkBrowse",
      },
    },
    {
      path: "/transaksi/bbk/print/:nomor",
      name: "BbkPrint",
      component: () => import("@/views/transaksi/BbkPrintView.vue"),
      meta: { layout: "BlankLayout", requiresAuth: true, title: "Cetak BBK" },
    },
    // Jurnal Umum
    {
      path: "/transaksi/jurnal-umum",
      name: "JurnalUmumBrowse",
      component: () => import("@/views/transaksi/JurnalUmumView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "26",
        title: "Jurnal Umum",
      },
    },
    {
      path: "/transaksi/jurnal-umum/create",
      name: "JurnalUmumCreate",
      component: () => import("@/views/transaksi/JurnalUmumFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "26",
        title: "Tambah Jurnal Umum",
        browseRoute: "JurnalUmumBrowse",
      },
    },
    {
      path: "/transaksi/jurnal-umum/edit/:nomor",
      name: "JurnalUmumEdit",
      component: () => import("@/views/transaksi/JurnalUmumFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "26",
        title: "Ubah Jurnal Umum",
        browseRoute: "JurnalUmumBrowse",
      },
    },
    // Rekonsiliasi Bank
    {
      path: "/transaksi/rekonsiliasi-bank",
      name: "RekonsiliasiBankBrowse",
      component: () => import("@/views/transaksi/RekonsiliasiBankView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "27",
        title: "Rekonsiliasi Bank",
      },
    },
    // Pengajuan Transfer
    {
      path: "/transaksi/pengajuan-transfer",
      name: "PengajuanTransferBrowse",
      component: () => import("@/views/transaksi/PengajuanTransferView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "28",
        title: "Pengajuan Transfer",
      },
    },
    {
      path: "/transaksi/pengajuan-transfer/create",
      name: "PengajuanTransferCreate",
      component: () =>
        import("@/views/transaksi/PengajuanTransferFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "28",
        title: "Baru Pengajuan Transfer",
        browseRoute: "PengajuanTransferBrowse",
      },
    },
    {
      path: "/transaksi/pengajuan-transfer/edit/:nomor",
      name: "PengajuanTransferEdit",
      component: () =>
        import("@/views/transaksi/PengajuanTransferFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "28",
        title: "Ubah Pengajuan Transfer",
        browseRoute: "PengajuanTransferBrowse",
      },
    },
    {
      path: "/transaksi/pengajuan-transfer/realisasi/:nomor",
      name: "PengajuanTransferRealisasi",
      component: () =>
        import("@/views/transaksi/PengajuanTransferFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "28",
        title: "Realisasi Pengajuan Transfer",
        browseRoute: "PengajuanTransferBrowse",
        isRealisasi: true,
      },
    },
    {
      path: "/transaksi/pengajuan-transfer/print/:nomor",
      name: "PengajuanTransferPrint",
      component: () =>
        import("@/views/transaksi/PengajuanTransferPrintView.vue"),
      meta: {
        layout: "BlankLayout",
        requiresAuth: true,
        title: "Cetak Pengajuan Transfer",
      },
    },
    // Terima Setoran
    {
      path: "/transaksi/terima-setoran",
      name: "TerimaSetoranBrowse",
      component: () => import("@/views/transaksi/TerimaSetoranView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "29",
        title: "Terima Setoran",
      },
    },
    {
      path: "/transaksi/terima-setoran",
      name: "TerimaSetoranBrowse",
      component: () => import("@/views/transaksi/TerimaSetoranView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "29",
        title: "Terima Setoran",
      },
    },
    {
      path: "/transaksi/terima-setoran/form/:nomor",
      name: "TerimaSetoranForm",
      component: () => import("@/views/transaksi/TerimaSetoranFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "29",
        title: "Terima Setoran Kasir",
        browseRoute: "TerimaSetoranBrowse",
      },
    },
    {
      path: "/transaksi/voucher-pembayaran",
      name: "VoucherPembayaran",
      component: () => import("@/views/transaksi/VoucherPembayaranView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "30",
        title: "Voucher Pembayaran",
      },
    },
    {
      path: "/transaksi/voucher-pembayaran/create",
      name: "VoucherPembayaranCreate",
      component: () =>
        import("@/views/transaksi/VoucherPembayaranFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "30",
        title: "Buat Voucher",
      },
    },
    {
      path: "/transaksi/voucher-pembayaran/edit/:nomor",
      name: "VoucherPembayaranEdit",
      component: () =>
        import("@/views/transaksi/VoucherPembayaranFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "30",
        title: "Ubah Voucher",
      },
    },
    {
      path: "/transaksi/voucher-pembayaran/print/:nomor",
      name: "VoucherPembayaranPrint",
      component: () =>
        import("@/views/transaksi/VoucherPembayaranPrintView.vue"),
      meta: {
        layout: "BlankLayout",
        requiresAuth: true,
        title: "Cetak Voucher",
      },
    },
    {
      path: "/transaksi/voucher-pembayaran/realisasi/create",
      name: "RealisasiVoucherCreate",
      component: () =>
        import("@/views/transaksi/VoucherPembayaranFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "30",
        title: "Realisasi Voucher",
        isRealisasi: true,
      },
    },
    {
      path: "/transaksi/voucher-pembayaran/realisasi/edit/:nomor",
      name: "RealisasiVoucherEdit",
      component: () =>
        import("@/views/transaksi/VoucherPembayaranFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "30",
        title: "Edit Realisasi Voucher",
        isRealisasi: true,
      },
    },

    // ── Posting ──
    {
      path: "/posting/pembayaran-customer",
      name: "PembayaranCustomerBrowse",
      component: () => import("@/views/posting/PembayaranCustomerView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "51",
        title: "Pembayaran Customer",
      },
    },
    {
      path: "/posting/pembayaran-customer/form",
      name: "PembayaranCustomerForm",
      component: () => import("@/views/posting/PembayaranCustomerFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "51",
        title: "Posting Pembayaran Customer",
        browseRoute: "PembayaranCustomerBrowse",
      },
    },
    {
      path: "/posting/pembayaran-cust-kaosan",
      name: "PembayaranCustKaosanBrowse",
      component: () => import("@/views/posting/PembayaranCustKaosanView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "52",
        title: "Pembayaran Customer Kaosan",
      },
    },
    {
      path: "/posting/pembayaran-cust-kaosan/form",
      name: "PembayaranCustKaosanForm",
      component: () =>
        import("@/views/posting/PembayaranCustKaosanFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "52",
        title: "Posting Pembayaran Customer Kaosan",
        browseRoute: "PembayaranCustKaosanBrowse",
      },
    },

    // ── Laporan ──
    {
      path: "/laporan/list-jurnal",
      name: "ListJurnal",
      component: () => import("@/views/laporan/ListJurnalView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        // tidak ada menuId
        title: "List Jurnal",
      },
    },
    {
      path: "/laporan/buku-besar",
      name: "LapBukuBesar",
      component: () => import("@/views/laporan/BukuBesarView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        title: "Buku Besar",
      },
    },
    {
      path: "/laporan/kasbon-belum-selesai",
      name: "LapKasbonBelumSelesai",
      component: () => import("@/views/laporan/KasbonBelumSelesaiView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        title: "Kasbon Belum Selesai",
      },
    },
    {
      path: "/laporan/rekonsiliasi-bank",
      name: "LapRekonsiliasi",
      component: () => import("@/views/laporan/LapRekonsiliasiBankView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        title: "Rekonsiliasi Bank",
      },
    },
    {
      path: "/laporan/stok-finance",
      name: "LapStokFinance",
      component: () => import("@/views/laporan/StokFinanceView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        title: "Stok Finance",
      },
    },
    {
      path: "/laporan/daftar-hutang",
      name: "LapDaftarHutang",
      component: () => import("@/views/laporan/DaftarHutangView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        title: "Daftar Hutang",
      },
    },

    // ── Tools ─────────────────────────────────────────────────────────
    {
      path: "/tools/users",
      name: "MasterUser",
      component: () => import("@/views/tools/MasterUserView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "1",
        title: "Master User",
      },
    },
    {
      path: "/tools/users/create",
      name: "MasterUserCreate",
      component: () => import("@/views/tools/MasterUserFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "1",
        title: "Tambah User",
        browseRoute: "MasterUser",
      },
    },
    {
      path: "/tools/users/edit/:kode",
      name: "MasterUserEdit",
      component: () => import("@/views/tools/MasterUserFormView.vue"),
      meta: {
        layout: "DefaultLayout",
        requiresAuth: true,
        menuId: "1",
        title: "Ubah User",
        browseRoute: "MasterUser",
      },
    },

    // ── Error Pages ───────────────────────────────────────────────────
    {
      path: "/403",
      name: "Unauthorized",
      component: () => import("@/views/errors/UnauthorizedView.vue"),
      meta: {
        layout: "BlankLayout",
        requiresAuth: false,
        title: "Akses Ditolak",
      },
    },
    {
      path: "/:pathMatch(.*)*",
      name: "NotFound",
      component: () => import("@/views/errors/NotFoundView.vue"),
      meta: {
        layout: "BlankLayout",
        requiresAuth: false,
        title: "Halaman Tidak Ditemukan",
      },
    },
  ],
});

// ── Navigation Guard ──────────────────────────────────────────────────
router.beforeEach(async (to) => {
  const authStore = useAuthStore();
  const permissionStore = usePermissionStore();
  const { loadRoutes, resetRoutes, isRoutesLoaded } = useDynamicRoutes();
  document.title = `${String(to.meta?.title || to.name || "Retail")} — BSM`;

  if (to.meta.requiresAuth && !authStore.isAuthenticated)
    return { name: "Login" };

  if (to.name === "Login" && authStore.isAuthenticated)
    return { name: "Dashboard" };

  // Logout / sesi berakhir → bersihkan route dinamis user sebelumnya
  // agar user berikutnya tidak mewarisi route lama.
  if (to.name === "Login") resetRoutes(router);

  // Muat route dinamis dari DB sekali per user. Route baru didaftarkan
  // via router.addRoute → ulangi navigasi agar router bisa match.
  if (to.meta.requiresAuth && !isRoutesLoaded.value) {
    await loadRoutes(router);
    if (isRoutesLoaded.value) return to.fullPath;
  }

  // Cek akses berbasis route (men_route di database).
  // Hanya untuk halaman ber-layout DefaultLayout yang menuntut permission
  // (menu DB). Core route seperti Dashboard bypass.
  if (
    to.meta.requiresAuth &&
    to.meta.requiresPermission !== false &&
    to.meta.layout !== "BlankLayout" &&
    !permissionStore.canAccessRoute(to.path)
  )
    return { name: "Unauthorized", query: { from: to.fullPath } };
});

// ── Auto-open Tab Bar ────────────────────────────────────────────────
const browseFallbackTitle: Record<string, string> = {
  "/transaksi/bpb": "Penerimaan Barang",
  "/transaksi/retur": "Retur Pembelian",
  "/transaksi/bayarSupplier": "Pembayaran Supplier",
  "/transaksi/terima-setoran": "Terima Setoran",
};

const prettyRouteName = (name: string) =>
  name
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
    .trim()
    .replace(/^./, (c) => c.toUpperCase());

router.afterEach((to) => {
  // Halaman BlankLayout (login/cetak/error) tidak punya tab
  if (to.meta.layout === "BlankLayout") return;

  const tabsStore = useTabsStore();
  if (!tabsStore.isReady) tabsStore.initDefaultTabs();

  const title = String(
    to.meta?.title ||
    browseFallbackTitle[to.path] ||
    (to.name ? prettyRouteName(String(to.name)) : "Halaman"),
  );

  tabsStore.openTab({
    title,
    path: to.path,
    query: to.query,
    closable: to.path !== "/",
  });
});

export default router;
